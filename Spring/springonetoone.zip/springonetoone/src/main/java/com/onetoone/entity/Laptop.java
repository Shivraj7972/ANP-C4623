package com.onetoone.entity;

public class Laptop {

}
