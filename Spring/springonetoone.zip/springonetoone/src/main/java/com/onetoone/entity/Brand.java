package com.onetoone.entity;

public class Brand {

}
