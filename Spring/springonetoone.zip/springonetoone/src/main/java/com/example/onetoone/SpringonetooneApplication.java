package com.example.onetoone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringonetooneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringonetooneApplication.class, args);
	}

}
