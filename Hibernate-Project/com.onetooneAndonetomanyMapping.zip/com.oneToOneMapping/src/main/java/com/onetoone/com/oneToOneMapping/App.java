package com.onetoone.com.oneToOneMapping;
import com.onetoone.entity.*;

import java.util.ArrayList;
import java.util.List;

import com.onetoone.dao.*;
public class App 
{
    public static void main( String[] args )
    {
    	Instructor instructor = new Instructor();
  	  InstructorDetail insd=new InstructorDetail();
  	  instructor.setFirstName("Shivraj");
  	  instructor.setLastName("salunke");
  	  instructor.setEmail("shiv@gmail.com");	
  	  insd.setYoutubeChannel("y.com");
  	  insd.setHobby("Playing Chess");
  	  insd.setInstructor(instructor);
  	  InstructorDao instructorDao = new InstructorDao();
        instructorDao.saveInstructor(instructor);
  	  //instructor.setInstructordetail(insd);
  	  List<Course> courses = new ArrayList<>();
  	  Course tempCourse1 = new Course();
  	  tempCourse1.setTitle("shiv");
  	  tempCourse1.setInstructor(instructor);
  	  courses.add(tempCourse1);
  	  
  	  CourseDao coursedao = new CourseDao();
        coursedao.saveCourse(tempCourse1);
    }
}
